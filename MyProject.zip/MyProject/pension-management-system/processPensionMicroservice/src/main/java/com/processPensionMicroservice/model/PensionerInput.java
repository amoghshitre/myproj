package com.processPensionMicroservice.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode
public class PensionerInput {
	private String name;
	private Date dateOfBirth;
	private String pan;
	private long aadharNumber;
	private String pensionType;

}
